<?php include 'header.php'; ?>
<main>
    <!-- Hero Section -->
    <div class="position-relative" style="height: 400px;">
        <img src="images/slide3.jpg" alt="Payroll & Compliance" class="w-100 h-100 object-fit-cover" style="filter: brightness(0.4);">
        <div class="position-absolute top-50 start-50 translate-middle text-center w-100 px-3">
            <div class="container">

                <h1 class="display-4 fw-bold text-white mb-3">Payroll & Compliance</h1>
                <p class="lead text-white-50 mx-auto" style="max-width: 800px;">Accurate processing integrated with rigorous legal adherence to protect your organization.</p>
            </div>
        </div>
    </div>

    <!-- Overview Section -->
    <section class="section-padding">
        <div class="container">
            <div class="row align-items-center flex-lg-row-reverse">
                <div class="col-lg-6 mb-4 mb-lg-0 ps-lg-5">
                    <h2 class="text-primary-navy mb-4">Risk-Free Operations</h2>
                    <p class="lead text-muted mb-4">Navigating India's complex labor regulations requires specialized expertise.</p>
                    <p>We offer comprehensive payroll management coupled with meticulous statutory compliance services (PF, ESI, PT, LWF). Our robust processes guarantee accurate, timely disbursements and flawless record-keeping, protecting your organization from regulatory penalties, legal disputes, and reputational risk.</p>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-sm-6">
                            <div class="bg-light-gray p-4 rounded h-100">
                                <i class="fas fa-file-invoice-dollar fa-2x text-accent-gold mb-3"></i>
                                <h5 class="text-dark">Accurate Payroll</h5>
                                <p class="small text-muted mb-0">Error-free, timely salary processing for your entire workforce.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-light-gray p-4 rounded h-100">
                                <i class="fas fa-shield-check fa-2x text-accent-gold mb-3"></i>
                                <h5 class="text-dark">Statutory Filings</h5>
                                <p class="small text-muted mb-0">PF, ESI, PT, and LWF registrations, deductions, and monthly returns.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-light-gray p-4 rounded h-100">
                                <i class="fas fa-book fa-2x text-accent-gold mb-3"></i>
                                <h5 class="text-dark">Record Keeping</h5>
                                <p class="small text-muted mb-0">Maintenance of all statutory registers and records as per state labor laws.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-light-gray p-4 rounded h-100">
                                <i class="fas fa-gavel fa-2x text-accent-gold mb-3"></i>
                                <h5 class="text-dark">Audit Support</h5>
                                <p class="small text-muted mb-0">Complete assistance during labor department inspections and audits.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="section-padding bg-light-gray">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="text-primary-navy">Our Payroll & Compliance Process</h2>
                <p class="text-muted">A highly structured methodology ensuring 100% adherence.</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="vertical-timeline">
                        <div class="timeline-step">
                            <div class="step-badge">Step 1</div>
                            <div class="step-content pb-4">
                                <h5 class="mb-2">Data Collation</h5>
                                <p class="text-muted small">Gathering attendance, leave data, and new joiner/leaver information securely.</p>
                                <div class="step-line"></div>
                            </div>
                        </div>
                        <div class="timeline-step">
                            <div class="step-badge">Step 2</div>
                            <div class="step-content pb-4">
                                <h5 class="mb-2">Payroll Processing</h5>
                                <p class="text-muted small">Calculating gross wages, statutory deductions, taxes, and net pay accurately.</p>
                                <div class="step-line"></div>
                            </div>
                        </div>
                        <div class="timeline-step">
                            <div class="step-badge">Step 3</div>
                            <div class="step-content pb-4">
                                <h5 class="mb-2">Disbursement & Payslips</h5>
                                <p class="text-muted small">Timely crediting of salaries to employee accounts and secure distribution of payslips.</p>
                                <div class="step-line"></div>
                            </div>
                        </div>
                        <div class="timeline-step">
                            <div class="step-badge">Step 4</div>
                            <div class="step-content pb-4">
                                <h5 class="mb-2">Statutory Remittance & Filing</h5>
                                <p class="text-muted small">Depositing PF/ESI dues and filing monthly/annual returns with government authorities.</p>
                                <div class="step-line"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Band -->
    <section class="cta-band">
        <div class="container">
            <h2>Ensure 100% <span>Statutory Compliance today</span></h2>
            <p class="lead mb-4 opacity-75">Outsource your payroll and compliance to the experts.</p>
            <a href="contact.php" class="btn btn-accent btn-lg px-5 py-3 shadow">Get in Touch</a>
        </div>
    </section>
</main>
<?php include 'footer.php'; ?>