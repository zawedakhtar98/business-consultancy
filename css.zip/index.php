<?php include 'header.php'; ?>
<main>
    <!-- Hero Slider Section -->
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <!-- Slide 1 -->
            <div class="carousel-item active">
                <div class="hero-slide" style="background-image: url('images/slide1.jpg');">
                    <div class="hero-overlay"></div>
                    <div class="container hero-content">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <h1 class="hero-headline">Workforce Solutions Designed for <span>Modern Businesses</span></h1>
                                <p class="hero-subheadline">Organizations today face increasing pressure to attract skilled talent, control workforce costs, and maintain statutory compliance. WorkForce2047 Partners bridges this gap by delivering practical workforce solutions backed by deep industry expertise and IIM alumni leadership.</p>
                                <div class="d-flex gap-3 flex-wrap">
                                    <a href="contact.php" class="btn btn-accent btn-lg px-4 py-3">Talk to Our Experts</a>
                                    <a href="services.php" class="btn btn-outline-light btn-lg px-4 py-3 border-2">Explore Our Services</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="carousel-item">
                <div class="hero-slide" style="background-image: url('images/slide2.jpg'); background-position: center 20%;">
                    <div class="hero-overlay"></div>
                    <div class="container hero-content">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <h1 class="hero-headline">Build a Smarter Workforce with <span>Apprenticeships</span></h1>
                                <p class="hero-subheadline">Structured, government-backed programs enable organizations to lower their wage bill by up to 22% while recovering eligible stipend costs through Central/State Government schemes. From registration to reimbursement, we handle every step.</p>
                                <div class="d-flex gap-3 flex-wrap">
                                    <a href="service-apprenticeship.php" class="btn btn-accent btn-lg px-4 py-3">Explore Apprenticeship Solutions</a>
                                    <a href="apprentship-calculator.php" class="btn btn-outline-light btn-lg px-4 py-3 border-2">Calculate Savings</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slide 3 -->
            <div class="carousel-item">
                <div class="hero-slide" style="background-image: url('images/slide3.jpg'); background-position: center top%;">
                    <div class="hero-overlay"></div>
                    <div class="container hero-content">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <h1 class="hero-headline">Compliance-Led <span>Workforce Management</span></h1>
                                <p class="hero-subheadline">Mitigate risk with our rigorous statutory and regulatory management. We navigate India's complex labor laws so you can focus on growth.</p>
                                <div class="d-flex gap-3 flex-wrap">
                                    <a href="service-consulting.php#labour-compliance" class="btn btn-accent btn-lg px-4 py-3">Explore Compliance Services</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- About Us Section -->
    <section id="about" class="section-padding bg-light-gray">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <span class="text-accent-gold fw-bold text-uppercase tracking-wide">Tailored Workforce Programs</span>
                    <h2 class="mt-2 mb-4">Driving Productivity Through <span class="text-accent-gold">Compliance-Led Strategy</span></h2>
                    <p class="lead mb-4">Each industry faces its own workforce demands, skill gaps, operating models, and regulatory requirements. WorkForce2047 Partners, founded and led by IIM alumni, brings a disciplined, data-informed approach to workforce planning and execution.</p>
                    <p class="mb-4">We work with organizations to design and manage apprenticeship-led workforce programs, backed by end-to-end labour compliance, payroll and flexible staffing support, all aligned to your business objectives.</p>
                    <a href="about.php" class="btn btn-outline-primary mt-2">Learn More About Us <i class="fas fa-arrow-right ms-2"></i></a>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-sm-6">
                            <div class="bg-white p-4 rounded shadow-sm text-center stat-item">
                                <h3><span class="stat-number" data-target="50">0</span><span class="stat-suffix">+</span></h3>
                                <p>Combined Years Expertise</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-white p-4 rounded shadow-sm text-center stat-item">
                                <h3><span class="stat-number" data-target="30">0</span><span class="stat-suffix">+</span></h3>
                                <p>Industry Sectors Covered</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-white p-4 rounded shadow-sm text-center stat-item">
                                <h3><span class="stat-number" data-target="22">0</span><span class="stat-suffix">%</span></h3>
                                <p>Lower Wage Bill Savings</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="bg-white p-4 rounded shadow-sm text-center stat-item">
                                <h3><span class="stat-number" data-target="100">0</span><span class="stat-suffix">%</span></h3>
                                <p>Compliance-Led Focus</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="section-padding">
        <div class="container">
            <div class="text-center mb-5">
                <span class="text-accent-gold fw-bold text-uppercase tracking-wide">Our Expertise</span>
                <h2 class="mt-2 mb-3">Integrated Workforce &amp; Apprenticeship Solutions</h2>
                <p class="text-muted mx-auto" style="max-width: 600px;">Comprehensive solutions tailored to streamline your operations, reduce risk, and build a resilient workforce.</p>
            </div>

            <div class="row g-4">
                <!-- Service 1 -->
                <div class="col-md-6 col-lg-3">
                    <div class="service-card" onclick="window.location.href='service-apprenticeship.php'">
                        <div class="icon-wrapper"><i class="fas fa-arrow-right"></i></div>
                        <h4>Apprenticeship Solutions</h4>
                        <p>NAPS, NATS, and State Schemes to build a trained talent pipeline while lowering wage bills up to 22%.</p>
                    </div>
                </div>

                <!-- Service 2 -->
                <div class="col-md-6 col-lg-3">
                    <div class="service-card" onclick="window.location.href='service-staffing.php'">
                        <div class="icon-wrapper"><i class="fas fa-arrow-right"></i></div>
                        <h4>Contract Staffing</h4>
                        <p>Flexible, compliant manpower solutions for project-based, seasonal, and ongoing business requirements.</p>
                    </div>
                </div>

                <!-- Service 3 -->
                <div class="col-md-6 col-lg-3">
                    <div class="service-card" onclick="window.location.href='service-payroll.php'">
                        <div class="icon-wrapper"><i class="fas fa-arrow-right"></i></div>
                        <h4>Payroll Management</h4>
                        <p>Accurate, timely payroll processing with full statutory deductions, filings, and audit readiness.</p>
                    </div>
                </div>

                <!-- Service 4 -->
                <div class="col-md-6 col-lg-3">
                    <div class="service-card" onclick="window.location.href='service-consulting.php'">
                        <div class="icon-wrapper"><i class="fas fa-arrow-right"></i></div>
                        <h4>Labour Compliance &amp; Advisory</h4>
                        <p>End-to-end statutory registrations, licensing, audits, HR policy design, and Management Development Programs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sectors Section -->
    <section id="sectors" class="section-padding bg-light-gray">
        <div class="container">
            <div class="text-center mb-5">
                <span class="text-accent-gold fw-bold text-uppercase tracking-wide">Industry-Specific Solutions</span>
                <h2 class="mb-3">Proven Results Across Sectors</h2>
                <p class="text-muted mx-auto" style="max-width: 750px;">Across retail, BFSI, manufacturing, EV, healthcare, logistics, IT/ITES, sunrise sectors, and emerging technologies, we help organizations build structured, future-ready talent pipelines.</p>
            </div>

            <div class="row g-4 pt-3">
                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-industry"></i></div>
                        <h5 class="text-primary-navy mt-2">Manufacturing &amp; Engineering</h5>
                        <p>Building a skilled shop-floor workforce across production, CNC operations, electrical & mechanical maintenance, and quality control.</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-car-battery"></i></div>
                        <h5 class="text-primary-navy mt-2">Automotive &amp; EV</h5>
                        <p>Preparing the workforce for the mobility revolution: EV assembly, battery manufacturing, diagnostics, and component testing.</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-solar-panel"></i></div>
                        <h5 class="text-primary-navy mt-2">Renewable Energy &amp; Solar</h5>
                        <p>Developing talent for India's clean energy future across solar PV installation, electrical systems, operations & maintenance.</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-laptop-code"></i></div>
                        <h5 class="text-primary-navy mt-2">IT / ITES / BPM</h5>
                        <p>Building the next generation of digital talent for technical support, customer operations, digital processes, and data ops.</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-truck-loading"></i></div>
                        <h5 class="text-primary-navy mt-2">E-Commerce &amp; Logistics</h5>
                        <p>Building the workforce behind India's supply chain: warehouse operations, inventory, picking & packing, and last-mile dispatch.</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="sector-card">
                        <div class="sector-badge"><i class="fas fa-university"></i></div>
                        <h5 class="text-primary-navy mt-2">BFSI &amp; Business Services</h5>
                        <p>Building talent for India's service economy with customer operations, documentation, digital support, and back-office processing.</p>
                    </div>
                </div>
            </div>

            <div class="text-center mt-5">
                <a href="sectors.php" class="btn btn-primary px-4 py-3">Explore All 13 Industry Sectors <i class="fas fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="section-padding bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="mb-3">How We Work</h2>
                <p class="text-muted">A streamlined, structured &amp; compliance-focused approach to workforce optimization.</p>
            </div>
            <div class="row pt-4">
                <div class="col-md-3">
                    <div class="process-step">
                        <div class="step-number">1</div>
                        <h5>Assess</h5>
                        <p class="text-muted small">We analyze your current workforce, compliance gaps, and talent needs.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step">
                        <div class="step-number">2</div>
                        <h5>Design Program</h5>
                        <p class="text-muted small">Develop a tailored strategy leveraging apprenticeships or staffing solutions.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step">
                        <div class="step-number">3</div>
                        <h5>Implement &amp; Staff</h5>
                        <p class="text-muted small">Source, screen, and onboard the right talent seamlessly into your operations.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="process-step">
                        <div class="step-number">4</div>
                        <h5>Ensure Compliance</h5>
                        <p class="text-muted small">Ongoing management of payroll, statutory filings, and program regulations.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <?php include 'team_section.php'; ?>

    <!-- Why Choose Us -->
    <section class="section-padding bg-light-gray" id="why-us">
        <div class="container">
            <div class="text-center mb-5">
                <span class="text-accent-gold fw-bold text-uppercase tracking-wide">Strategic Human Capital Partner</span>
                <h2 class="mt-2 mb-3 display-6 fw-bold text-dark">Why <span class="text-primary-navy">WorkForce</span><span class="text-accent-gold">2047</span> <span class="text-primary-navy">Partners?</span></h2>
                <p class="lead text-dark fw-semibold mx-auto" style="max-width: 700px;">Because workforce transformation needs more than manpower.</p>
            </div>
            <div class="row align-items-center mb-5">
                <div class="col-lg-7 pe-lg-5">
                    <p class="text-muted mb-4" style="font-size: 1.05rem; line-height: 1.8;">
                        Led by IIM alumni, <strong>WorkForce2047 Partners</strong> brings together over <strong>50+ years of combined workforce and business operations experience</strong>, along with deep expertise in apprenticeship and workforce management. We help organizations build a workforce that is more efficient, compliant, and future-ready.
                    </p>
                    <p class="text-muted mb-4" style="font-size: 1.05rem; line-height: 1.8;">
                        Our approach goes beyond filling positions. We work as a strategic partner, aligning talent, compliance, and operations to your business goals, so you can focus on growth while we manage the complexity.
                    </p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="about.php#what-makes-us-different" class="btn btn-primary">See What Makes Us Different <i class="fas fa-arrow-right ms-2"></i></a>
                        <a href="contact.php" class="btn btn-outline-primary">Connect with an Expert</a>
                    </div>
                </div>
                <div class="col-lg-5 mt-5 mt-lg-0">
                    <img src="images/why_us_indian_handshake_1789535515706.jpg" alt="Why Choose Us" class="img-fluid rounded-4 shadow">
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="section-padding bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <span class="text-accent-gold fw-bold text-uppercase tracking-wide">Client Testimonials</span>
                <h2 class="mt-2 mb-3">What Our Partners Say</h2>
                <p class="text-muted mx-auto" style="max-width: 650px;">Trusted by leaders across industries for apprenticeship management, compliance, and workforce solutions.</p>
            </div>

            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="testimonial-card">
                        <div>
                            <div class="quote-icon"><i class="fas fa-quote-left"></i></div>
                            <p class="quote-text">“WorkForce2047 Partners brought much-needed structure and clarity to our apprenticeship program. Their understanding of operational requirements and hands-on approach made the entire process easier for our teams to manage. They have been a dependable partner in helping us build a more structured workforce.”</p>
                        </div>
                        <div>
                            <hr class="my-3 opacity-25">
                            <p class="author-name">— Operations Head</p>
                            <span class="author-role">BPO Industry</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="testimonial-card">
                        <div>
                            <div class="quote-icon"><i class="fas fa-quote-left"></i></div>
                            <p class="quote-text">“What stood out to us was their ability to understand both the business and HR perspective. WorkForce2047 Partners helped us navigate the apprenticeship framework while keeping the process aligned with our workforce requirements. Their approach is professional, responsive and solution-oriented.”</p>
                        </div>
                        <div>
                            <hr class="my-3 opacity-25">
                            <p class="author-name">— CHRO</p>
                            <span class="author-role">IT Industry</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="testimonial-card">
                        <div>
                            <div class="quote-icon"><i class="fas fa-quote-left"></i></div>
                            <p class="quote-text">“Managing workforce requirements across retail demands flexibility, speed and strong execution. WorkForce2047 Partners brought a practical approach to apprenticeship and workforce management, helping us simplify the process and create a more structured talent pipeline.”</p>
                        </div>
                        <div>
                            <hr class="my-3 opacity-25">
                            <p class="author-name">— Business Head</p>
                            <span class="author-role">Hospitality &amp; Retail Industry</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="testimonial-card">
                        <div>
                            <div class="quote-icon"><i class="fas fa-quote-left"></i></div>
                            <p class="quote-text">“WorkForce2047 Partners has been an invaluable extension of our HR and operations team. Their apprenticeship expertise helped us build a structured pipeline of skilled shop-floor talent, while their handling of labour compliance and payroll gave us complete confidence during audits and inspections. We now work with a single accountable partner instead of multiple vendors, and the difference in efficiency, cost control, and peace of mind has been significant.”</p>
                        </div>
                        <div>
                            <hr class="my-3 opacity-25">
                            <p class="author-name">— CEO</p>
                            <span class="author-role">MSME, Manufacturing</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="testimonial-card">
                        <div>
                            <div class="quote-icon"><i class="fas fa-quote-left"></i></div>
                            <p class="quote-text">“We engaged WorkForce2047 Partners to simplify our apprenticeship program and workforce administration. Within months, we saw a more reliable talent pipeline, error-free payroll, and audit-ready compliance across our locations. Their team understands manufacturing operations, and it shows.”</p>
                        </div>
                        <div>
                            <hr class="my-3 opacity-25">
                            <p class="author-name">— Compliance Lead</p>
                            <span class="author-role">Food Processing Industry</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Cities Section -->
    <?php include 'cities_section.php'; ?>

    <!-- CTA Band -->
    <section class="cta-band">
        <div class="container">
            <h2>Ready to Build a Compliant, <span>Future-Ready Workforce?</span></h2>
            <p class="lead mb-4 opacity-75">Connect with our corporate consultants today to discuss your organization's needs.</p>
            <a href="contact.php" class="btn btn-accent btn-lg px-5 py-3 shadow">Schedule a Free Consultation</a>
        </div>
    </section>
</main>
<?php include 'footer.php'; ?>